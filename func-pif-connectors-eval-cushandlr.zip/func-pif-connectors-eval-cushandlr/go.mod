module azure-function-app

go 1.23.0

toolchain go1.24.2

require (
	github.com/go-ldap/ldap/v3 v3.4.11
	github.com/google/uuid v1.6.0
)

require (
	github.com/Azure/go-ntlmssp v0.0.0-20221128193559-754e69321358 // indirect
	github.com/go-asn1-ber/asn1-ber v1.5.8-0.20250403174932-29230038a667 // indirect
	golang.org/x/crypto v0.36.0 // indirect
)
