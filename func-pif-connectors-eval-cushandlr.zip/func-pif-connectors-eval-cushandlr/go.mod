module azure-function-app

go 1.16
