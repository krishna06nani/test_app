package main

import (
"encoding/json"
"fmt"
"net/http"
)

func handler(w http.ResponseWriter, r *http.Request) {
var data map[string]interface{}
err := json.NewDecoder(r.Body).Decode(&data)
if err != nil {
http.Error(w, err.Error(), http.StatusBadRequest)
return
}

response := map[string]string{"message": "Hello from Azure Function!"}
w.Header().Set("Content-Type", "application/json")
json.NewEncoder(w).Encode(response)
}

func main() {
http.HandleFunc("/api/ldap_conn_eval_ht", handler)
port := "8080"
fmt.Printf("Listening on port %s...\n", port)
http.ListenAndServe(":"+port, nil)
}
