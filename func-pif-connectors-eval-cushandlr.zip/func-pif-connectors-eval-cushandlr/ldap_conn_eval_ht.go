package main

import (
"encoding/json"
"fmt"
"log"
"net/http"
"os"
"time"

"github.com/go-ldap/ldap/v3"
"github.com/google/uuid"
)

type LDAPConnector struct {
ServerURI string
UserDN    string
Password  string
PoolSize  int
}

func getConnection() (*ldap.Conn, float64, error) {
startTime := time.Now()

conn, err := ldap.DialURL("LDAP://wwldap.k.net")
if err != nil {
return nil, 0, err
}

err = conn.Bind("ycbex@in.net", "Esushq9Rd68m21ShYJUI9n")
if err != nil {
return nil, 0, err
}

endTime := time.Now()
connTimeDiff := endTime.Sub(startTime).Seconds()

log.Printf("time taken to create db connectionpool :: %.6f seconds", connTimeDiff)
return conn, connTimeDiff, nil
}

func ldapConnEvalHTHandler(w http.ResponseWriter, r *http.Request) {
tid := uuid.New()
log.Println("Go HTTP trigger function processed a request.")

conn, connTimeDiff, err := getConnection()
if err != nil {
http.Error(w, fmt.Sprintf("Error : %v", err), http.StatusInternalServerError)
return
}
defer conn.Close()

startTime := time.Now()

searchRequest := ldap.NewSearchRequest(
"dc=quintiles,dc=net",
ldap.ScopeWholeSubtree, ldap.NeverDerefAliases, 0, 0, false,
"(proxyAddresses=smtp:gu.ry@iqvia.com)",
[]string{"proxyAddresses"},
nil,
)

searchResults, err := conn.Search(searchRequest)
if err != nil {
http.Error(w, fmt.Sprintf("Error : %v", err), http.StatusInternalServerError)
return
}

results := []map[string]interface{}{}
for _, entry := range searchResults.Entries {
entryMap := map[string]interface{}{
"dn":         entry.DN,
"attributes": entry.GetAttributeValues("proxyAddresses"),
}
results = append(results, entryMap)
}

log.Printf(":: %s :: ldap search operation results :: %s seconds", tid, results)

endTime := time.Now()
ldapTimeDiff := endTime.Sub(startTime).Seconds()

respData, err := json.MarshalIndent(results, "", "    ")
if err != nil {
http.Error(w, fmt.Sprintf("Error : %v", err), http.StatusInternalServerError)
return
}

w.Header().Set("Content-Type", "application/json")
w.Header().Set("tid", tid.String())
w.Header().Set("function-execution-time-sec", fmt.Sprintf("%.6f", ldapTimeDiff))
w.Header().Set("ldap-opr-execution-time-sec", fmt.Sprintf("%.6f", ldapTimeDiff))
w.Header().Set("ldap-conpool-creation-time-sec", fmt.Sprintf("%.6f", connTimeDiff))
w.WriteHeader(http.StatusOK)
w.Write(respData)
}

func main() {
http.HandleFunc("/ldap_conn_eval_ht", ldapConnEvalHTHandler)
port := os.Getenv("FUNCTIONS_CUSTOMHANDLER_PORT")
log.Fatal(http.ListenAndServe(fmt.Sprintf(":%s", port), nil))
}
