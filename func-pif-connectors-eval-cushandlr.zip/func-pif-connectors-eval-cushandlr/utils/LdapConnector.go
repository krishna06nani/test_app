package LdapConnector

import (
    "fmt"
    "log"
    "sync"
    "time"

    "github.com/go-ldap/ldap/v3"
)

type LdapConnector struct {
    serverURI    string
    userDN       string
    password     string
    poolSize     int
    idleTimeout  time.Duration
    pool         chan *ldap.Conn
    lock         sync.Mutex
}

func NewLdapConnector(serverURI, userDN, password string, poolSize int, idleTimeout time.Duration) *LdapConnector {
    connector := &LdapConnector{
        serverURI:   serverURI,
        userDN:      userDN,
        password:    password,
        poolSize:    poolSize,
        idleTimeout: idleTimeout,
        pool:        make(chan *ldap.Conn, poolSize),
    }
    connector.initializePool()
    go connector.idleTimeoutHandler()
    return connector
}

func (lc *LdapConnector) initializePool() {
    var wg sync.WaitGroup
    for i := 0; i < lc.poolSize; i++ {
        wg.Add(1)
        go func() {
            defer wg.Done()
            lc.createConnection()
        }()
    }
    wg.Wait()
}

func (lc *LdapConnector) createConnection() {
    conn, err := ldap.DialURL(lc.serverURI)
    if err != nil {
        log.Printf("ERROR: Error creating connection: %v", err)
        return
    }
    err = conn.Bind(lc.userDN, lc.password)
    if err != nil {
        log.Printf("ERROR: Error binding connection: %v", err)
        return
    }
    lc.lock.Lock()
    lc.pool <- conn
    lc.lock.Unlock()
    log.Printf("INFO: Connection created: %v", conn)
}

func (lc *LdapConnector) idleTimeoutHandler() {
    ticker := time.NewTicker(lc.idleTimeout / 2)
    defer ticker.Stop()
    for range ticker.C {
        lc.lock.Lock()
        newPool := make(chan *ldap.Conn, lc.poolSize)
        for len(lc.pool) > 0 {
            conn := <-lc.pool
            if time.Since(conn.LastUsed()) < lc.idleTimeout {
                newPool <- conn
            } else {
                conn.Close()
            }
        }
        lc.pool = newPool
        lc.lock.Unlock()
    }
}

func (lc *LdapConnector) getConnection() (*ldap.Conn, error) {
    select {
    case conn := <-lc.pool:
        err := conn.Bind(lc.userDN, lc.password)
        if err != nil {
            log.Printf("ERROR: Error binding connection: %v", err)
            return nil, err
        }
        return conn, nil
    case <-time.After(5 * time.Second):
        log.Println("WARNING: Pool is empty, reinitializing...")
        lc.initializePool()
        return lc.getConnection()
    }
}

func (lc *LdapConnector) releaseConnection(conn *ldap.Conn) {
    lc.lock.Lock()
    lc.pool <- conn
    lc.lock.Unlock()
}

func (lc *LdapConnector) closeAllConnections() {
    lc.lock.Lock()
    defer lc.lock.Unlock()
    for len(lc.pool) > 0 {
        conn := <-lc.pool
        conn.Close()
    }
}

func (lc *LdapConnector) search(searchBase, searchFilter string, attributes []string) ([]*ldap.Entry, error) {
    conn, err := lc.getConnection()
    if err != nil {
        return nil, err
    }
    defer lc.releaseConnection(conn)

    searchRequest := ldap.NewSearchRequest(
        searchBase,
        ldap.ScopeWholeSubtree, ldap.NeverDerefAliases, 0, 0, false,
        searchFilter,
        attributes,
        nil,
    )

    sr, err := conn.Search(searchRequest)
    if err != nil {
        log.Printf("ERROR: Error in search operation: %v", err)
        return nil, err
    }
    return sr.Entries, nil
}

func (lc *LdapConnector) closeConnectionPool() {
    lc.closeAllConnections()
}

func main() {
    connector := NewLdapConnector("ldap://example.com", "cn=admin,dc=example,dc=com", "password", 10, 300*time.Second)
    entries, err := connector.search("dc=example,dc=com", "(objectClass=person)", []string{"cn", "sn"})
    if err != nil {
        log.Fatalf("ERROR: %v", err)
    }
    for _, entry := range entries {
        fmt.Printf("CN: %s, SN: %s\n", entry.GetAttributeValue("cn"), entry.GetAttributeValue("sn"))
    }
    connector.closeConnectionPool()
}
