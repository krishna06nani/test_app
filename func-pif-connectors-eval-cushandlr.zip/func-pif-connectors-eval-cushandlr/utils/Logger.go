package LdapConnector

import (
	"log"
)

func init() {
	log.SetFlags(log.LstdFlags | log.Lshortfile)
}

func Log(level string, message string) {
	switch level {
	case "INFO":
		log.Println("INFO:", message)
	case "ERROR":
		log.Println("ERROR:", message)
	case "WARNING":
		log.Println("WARNING:", message)
	default:
		log.Println("DEBUG:", message)
	}
}
